// Re-export EnhancedTabbedCoachPanel for backwards compatibility
import React from 'react';
export { FixedEnhancedTabbedCoachPanel as TabbedCoachPanel } from './EnhancedTabbedCoachPanel';